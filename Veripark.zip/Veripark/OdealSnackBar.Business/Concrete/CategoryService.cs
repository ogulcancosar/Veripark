﻿using System;
using System.Collections.Generic;
using System.Text;
using OdealSnackBar.Business.Abstract;
using OdealSnackBar.DataAccess.Abstract;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.Business.Concrete
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryDal _categoryDal;

        public CategoryService(ICategoryDal categoryDal)
        {
            _categoryDal = categoryDal;
        }

        public List<Category> GetAll()
        {
           return _categoryDal.GetList();
        }
    }
}
