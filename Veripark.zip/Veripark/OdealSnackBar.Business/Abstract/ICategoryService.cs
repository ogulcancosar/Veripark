﻿using System;
using System.Collections.Generic;
using System.Text;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.Business.Abstract
{
    public interface ICategoryService
    {
        List<Category> GetAll();
    }
}
