﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OdealSnackBar.Business.Abstract;
using OdealSnackBar.WebMvcUI.Models;
using OdealSnackBar.WebMvcUI.Services;

namespace OdealSnackBar.WebMvcUI.Controllers
{
    public class CartController : Controller
    {
        private readonly ICartSessionService _cartSessionService;
        private readonly ICartService _cartService;
        private readonly IProductService _productService;

        public CartController(ICartSessionService cartSessionService, ICartService cartService, IProductService productService)
        {
            _cartSessionService = cartSessionService;
            _cartService = cartService;
            _productService = productService;
        }

        public ActionResult AddToCart(int productId)
        {
            var productToBeAdded = _productService.GetById(productId);

            var cart = _cartSessionService.GetCart();

            _cartService.AddToCart(cart,productToBeAdded);

            _cartSessionService.SetCart(cart);

            TempData.Add("message", String.Format("Your product, {0}, was successfully added to the cart!", productToBeAdded.ProductName));

            return RedirectToAction("Index", "Product");
        }

        public ActionResult List()
        {
            var cart = _cartSessionService.GetCart();
            CartListViewModel model = new CartListViewModel
            {
                Cart = cart
            };
            return View(model);
        }

        public ActionResult Remove(int productId)
        {
            var cart = _cartSessionService.GetCart();
            _cartService.RemoveFromCart(cart, productId);
            _cartSessionService.SetCart(cart);
            TempData.Add("message", String.Format("Your product was successfully removed from the cart!"));
            return RedirectToAction("List");
        }

        public ActionResult Complete()
        {
            var cart = _cartSessionService.GetCart();
            ShippingDetailsViewModel model = new ShippingDetailsViewModel
            {
                Cart = cart,
            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Complete(ShippingDetailsViewModel value)
        {
            var cart = _cartSessionService.GetCart();
            ShippingDetailsViewModel model = new ShippingDetailsViewModel
            {
                Cart = cart,
                PaymentType = value.PaymentType
            };

            return View(model);
        }
        
    }
}
