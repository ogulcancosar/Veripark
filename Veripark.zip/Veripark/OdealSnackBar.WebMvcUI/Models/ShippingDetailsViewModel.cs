﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.WebMvcUI.Models
{
    public class ShippingDetailsViewModel
    {
        public Cart Cart { get; set; }
        public string PaymentType { get; set; }
        
    }
}
