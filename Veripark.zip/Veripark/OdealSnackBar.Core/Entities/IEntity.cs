﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OdealSnackBar.Core.Entities
{
    public interface IEntity
    {
    }
}
