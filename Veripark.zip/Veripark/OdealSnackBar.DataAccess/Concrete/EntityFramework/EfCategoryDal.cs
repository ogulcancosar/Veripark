﻿using System;
using System.Collections.Generic;
using System.Text;
using OdealSnackBar.Core.DataAccess.EntityFramework;
using OdealSnackBar.DataAccess.Abstract;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.DataAccess.Concrete.EntityFramework
{
    public class EfCategoryDal : EfEntityRepositoryBase<Category, OdealDBContext>, ICategoryDal
    {
    }
}
