﻿using System;
using System.Collections.Generic;
using System.Text;
using OdealSnackBar.Core.DataAccess.EntityFramework;
using OdealSnackBar.DataAccess.Abstract;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.DataAccess.Concrete.EntityFramework
{
    public class EfProductDal : EfEntityRepositoryBase<Product, OdealDBContext>, IProductDal
    {
    }
}
