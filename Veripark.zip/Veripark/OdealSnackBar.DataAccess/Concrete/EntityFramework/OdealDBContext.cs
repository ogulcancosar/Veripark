﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.DataAccess.Concrete.EntityFramework
{
    public class OdealDBContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=OGULCANCOSAR\SQLSERVER2017EXP;Database=OdealDB; Trusted_Connection=true");
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
