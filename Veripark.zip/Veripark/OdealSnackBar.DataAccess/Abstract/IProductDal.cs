﻿using System;
using System.Collections.Generic;
using System.Text;
using OdealSnackBar.Core.DataAccess;
using OdealSnackBar.Entities.Concrete;

namespace OdealSnackBar.DataAccess.Abstract
{
    public interface IProductDal : IEntityRepository<Product>
    {
    }
}
